// import { API_PATHS } from './apiPaths';
// import axiosInstance from './axiosInstance';

// Image upload disabled - localStorage cannot store files

// const uploadImage = async (imageFile) => {
//   // ... implementation commented out
// };

// export default uploadImage;