// src/utils/axiosInstance.js
// import axios from 'axios';

// Axios instance disabled - using local storage only

// const axiosInstance = axios.create({
//   baseURL: 'http://localhost:8000',
// });

// axiosInstance.interceptors.response.use(
//   (response) => response,
//   (error) => {
//     console.warn("Using dummy data instead of backend:", error.config?.url);

//     const dummyResponses = {
//       "/api/auth/login": { token: "dummy-token", user: { name: "Test User" } },
//       "/api/incomes": [{ id: 1, amount: 1000, source: "Salary" }],
//       "/api/expenses/get": [{ id: 1, amount: 500, category: "Food" }],
//     };

//     const url = error.config?.url;

//     if (url && dummyResponses[url]) {
//       return Promise.resolve({ data: dummyResponses[url] });
//     }

//     return Promise.resolve({ data: {} });
//   }
// );

// export default axiosInstance;

// Local storage utilities will be used instead
export const localStorageUtils = {
  get: (key) => {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : null;
  },
  set: (key, value) => {
    localStorage.setItem(key, JSON.stringify(value));
  },
  remove: (key) => {
    localStorage.removeItem(key);
  },
  clear: () => {
    localStorage.clear();
  }
};

export default localStorageUtils;