// Backend disconnected - using local storage only
export const BASE_URL = "";

export const API_PATHS = {
  // AUTH: {
  //   LOGIN: "/api/auth/login",
  //   REGISTER: "/api/auth/register",
  //   GET_USER_INFO: "/api/auth/me",
  // },
  // DASHBOARD: {
  //   GET_DATA: "/api/dashboard",
  // },
  // INCOME: {
  //   ADD_INCOME: "/api/incomes/add",
  //   GET_ALL_INCOME: "/api/incomes",
  //   DELETE_INCOME: (incomeId) => `/api/incomes/${incomeId}`,
  //   DOWNLOAD_INCOME: "/api/incomes/downloadExcel",
  // },
  // EXPENSE: {
  //   ADD_EXPENSE: "/api/expenses/add",
  //   GET_ALL_EXPENSE: "/api/expenses/get",
  //   DELETE_EXPENSE: (expenseId) => `/api/expenses/${expenseId}`,
  //   DOWNLOAD_EXPENSE: "/api/expenses/downloadExcel",
  // },
  // PROFILE: {
  //   GET_PROFILES: "/api/profiles",
  //   CREATE_PROFILE: "/api/profiles",
  //   UPDATE_PROFILE: (profileId) => `/api/profiles/${profileId}`,
  //   DELETE_PROFILE: (profileId) => `/api/profiles/${profileId}`,
  // }
};