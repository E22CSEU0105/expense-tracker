// src/hooks/useUserAuth.jsx
import { useContext, useEffect, useRef, useState } from "react";
import { UserContext } from "../context/UserContext";
import { useNavigate } from "react-router-dom";

export const useUserAuth = () => {
  const { user, updateUser, clearUser } = useContext(UserContext);
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(!user);
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  useEffect(() => {
    if (user) {
      setIsLoading(false);
      return;
    }

    const fetchUserInfoFromLocalStorage = () => {
      try {
        const storedUser = localStorage.getItem("user");
        if (storedUser) {
          updateUser(JSON.parse(storedUser));
        } else {
          clearUser();
          navigate("/login", { replace: true });
        }
      } catch (err) {
        console.error("Failed to fetch user info from localStorage:", err);
        clearUser();
        navigate("/login", { replace: true });
      } finally {
        if (isMounted.current) setIsLoading(false);
      }
    };

    fetchUserInfoFromLocalStorage();
  }, [user, updateUser, clearUser, navigate]);

  return { user, isLoading };
};
