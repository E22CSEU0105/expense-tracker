import React, { useState } from 'react';
import './AddExpenseForm.css';

const AddExpenseForm = ({ onClose, onExpenseAdded }) => {
    const [formData, setFormData] = useState({
        amount: '',
        category: '',
        description: '',
        date: new Date().toISOString().split('T')[0]
    });
    const [selectedIcon, setSelectedIcon] = useState('💰');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const expenseCategories = [
        { icon: '🍔', name: 'Food & Dining' },
        { icon: '🚗', name: 'Transportation' },
        { icon: '🏠', name: 'Housing' },
        { icon: '🛒', name: 'Shopping' },
        { icon: '💊', name: 'Healthcare' },
        { icon: '🎮', name: 'Entertainment' },
        { icon: '📚', name: 'Education' },
        { icon: '✈️', name: 'Travel' },
        { icon: '💡', name: 'Utilities' },
        { icon: '🎁', name: 'Gifts' },
        { icon: '💻', name: 'Technology' },
        { icon: '🏋️', name: 'Fitness' },
        { icon: '🐾', name: 'Pets' },
        { icon: '🚬', name: 'Personal Care' },
        { icon: '📱', name: 'Subscriptions' },
        { icon: '🚘', name: 'Car Maintenance' },
        { icon: '👕', name: 'Clothing' },
        { icon: '🍼', name: 'Child Care' },
        { icon: '💰', name: 'Other' }
    ];

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleCategorySelect = (category) => {
        setFormData(prev => ({
            ...prev,
            category: category.name
        }));
        setSelectedIcon(category.icon);
    };

    const handleAmountChange = (e) => {
        const value = e.target.value;
        // Allow only numbers and decimal point
        if (value === '' || /^\d*\.?\d*$/.test(value)) {
            setFormData(prev => ({
                ...prev,
                amount: value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!formData.amount || !formData.category) {
            alert('Please fill in all required fields');
            return;
        }

        setIsSubmitting(true);

        try {
            // Create expense object without profileId
            const newExpense = {
                amount: parseFloat(formData.amount),
                category: formData.category,
                description: formData.description,
                date: formData.date,
                icon: selectedIcon
            };

            // Call the parent handler
            onExpenseAdded?.(newExpense);
            onClose?.();
            
            // Reset form
            setFormData({
                amount: '',
                category: '',
                description: '',
                date: new Date().toISOString().split('T')[0]
            });
            setSelectedIcon('💰');
            
        } catch (error) {
            console.error('Error adding expense:', error);
            alert('Error adding expense. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    const formatDateDisplay = (dateString) => {
        if (!dateString) return 'dd - mm - yyyy';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        }).replace(/\//g, ' - ');
    };

    return (
        <div className="add-expense-form">
            <div className="form-header">
                <h2>Add Expense</h2>
            </div>

            {/* Pick Icon Section */}
            <div className="icon-section">
                <h3>Pick Icon</h3>
                <div className="icon-grid">
                    {expenseCategories.map((category, index) => (
                        <button
                            key={index}
                            type="button"
                            className={`icon-option ${formData.category === category.name ? 'selected' : ''}`}
                            onClick={() => handleCategorySelect(category)}
                            title={category.name}
                        >
                            <span className="icon">{category.icon}</span>
                        </button>
                    ))}
                </div>
            </div>

            <div className="divider"></div>

            <form onSubmit={handleSubmit} className="expense-form">
                {/* Expense Category */}
                <div className="form-group">
                    <label htmlFor="category">Expense Category</label>
                    <div className="category-display">
                        <span className="selected-icon">{selectedIcon}</span>
                        <input
                            type="text"
                            id="category"
                            name="category"
                            value={formData.category}
                            onChange={handleInputChange}
                            placeholder="Food, Transport, Bills, etc."
                            required
                            className="category-input"
                        />
                    </div>
                    <div className="category-suggestions">
                        {expenseCategories
                            .filter(cat => 
                                cat.name.toLowerCase().includes(formData.category.toLowerCase()) &&
                                cat.name !== formData.category
                            )
                            .slice(0, 3)
                            .map((cat, index) => (
                                <button
                                    key={index}
                                    type="button"
                                    className="suggestion-item"
                                    onClick={() => handleCategorySelect(cat)}
                                >
                                    <span className="icon">{cat.icon}</span>
                                    {cat.name}
                                </button>
                            ))}
                    </div>
                </div>

                {/* Amount */}
                <div className="form-group">
                    <label htmlFor="amount">Amount</label>
                    <div className="amount-input-container">
                        <span className="currency-symbol">$</span>
                        <input
                            type="text"
                            id="amount"
                            name="amount"
                            value={formData.amount}
                            onChange={handleAmountChange}
                            placeholder="0.00"
                            required
                            className="amount-input"
                        />
                    </div>
                </div>

                {/* Date */}
                <div className="form-group">
                    <label htmlFor="date">Date</label>
                    <div className="date-input-container">
                        <input
                            type="date"
                            id="date"
                            name="date"
                            value={formData.date}
                            onChange={handleInputChange}
                            required
                            className="date-input"
                        />
                        <span className="date-display">
                            {formatDateDisplay(formData.date)}
                        </span>
                    </div>
                </div>

                {/* Description */}
                <div className="form-group">
                    <label htmlFor="description">Description (Optional)</label>
                    <textarea
                        id="description"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        placeholder="Add any notes about this expense..."
                        rows="3"
                        className="description-input"
                    />
                </div>

                <div className="divider"></div>

                {/* Action Buttons */}
                <div className="form-actions">
                    <button
                        type="button"
                        onClick={onClose}
                        className="btn-cancel"
                        disabled={isSubmitting}
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="btn-submit"
                        disabled={isSubmitting || !formData.amount || !formData.category}
                    >
                        {isSubmitting ? 'Adding...' : 'Add Expense'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default AddExpenseForm;