import React from "react";
import "../../../components/layouts/dashboard.css";

const ExpenseList = ({ transactions, onDelete, onDownload }) => {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'short' });
    const year = date.getFullYear();
    
    // Add ordinal suffix to day
    const suffix = ['th', 'st', 'nd', 'rd'];
    const relevantDigits = (day % 100);
    const suffixIndex = (relevantDigits - 20) % 10;
    const daySuffix = suffix[suffixIndex] || suffix[relevantDigits] || suffix[0];
    
    return `${day}${daySuffix} ${month} ${year}`;
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (transactions.length === 0) {
    return (
      <div className="income-list-container">
        <div className="income-list-header">
          <h2>All Expenses</h2>
          <button className="download-btn" onClick={onDownload}>
            <i className="fas fa-download"></i>
            Download
          </button>
        </div>
        <div className="no-income-message">
          <p>No expense records yet. Click "Add Expense" to get started.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="income-list-container">
      <div className="income-list-header">
        <h2>All Expenses</h2>
        <button className="download-btn" onClick={onDownload}>
          <i className="fas fa-download"></i>
          Download
        </button>
      </div>

      <div className="income-items-list">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="income-item">
            <div className="income-item-icon">
              <span>{transaction.icon || "💰"}</span>
            </div>
            
            <div className="income-item-content">
              <div className="income-source-row">
                <h3 className="income-source">{transaction.category}</h3>
                <span className="income-amount expense-amount">-{formatCurrency(transaction.amount)}</span>
              </div>
              
              <div className="income-details-row">
                <span className="income-category">{transaction.category}</span>
                <span className="income-date">{formatDate(transaction.date)}</span>
              </div>

              {transaction.description && (
                <div className="income-description">
                  <p>{transaction.description}</p>
                </div>
              )}
            </div>

            <button
              className="income-delete-btn"
              onClick={() => onDelete(transaction.id)}
            >
              <i className="fas fa-trash"></i>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExpenseList;