// src/components/layouts/DashboardLayout.jsx
import React, { useContext, useState } from "react";
import { UserContext } from "../../context/UserContext";
import Navbar from "./Navbar";
import SideMenu from "./SideMenu";
import "./dashboard.css";

const DashboardLayout = ({ children, activeMenu }) => {
  const { user } = useContext(UserContext);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  return (
    <div className="dashboard-layout">
      <Navbar 
        activeMenu={activeMenu} 
        onMenuToggle={() => setShowMobileMenu(!showMobileMenu)}
        showMobileMenu={showMobileMenu}
      />
      
      {user && (
        <div className="dashboard-content-wrapper">
          {/* Mobile menu overlay */}
          {showMobileMenu && (
            <div 
              className="mobile-menu-overlay"
              onClick={() => setShowMobileMenu(false)}
            ></div>
          )}
          
          {/* Sidebar */}
          <div className={`dashboard-sidebar ${showMobileMenu ? 'open' : ''}`}>
            <SideMenu activeMenu={activeMenu} />
          </div>

          {/* Main content */}
          <div className="dashboard-main-content">
            {children}
          </div>
        </div>
      )}
    </div>
  );
};

export default DashboardLayout;