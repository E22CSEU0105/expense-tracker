// src/components/layouts/SideMenu.jsx
import React, { useContext } from "react";
import { SIDE_MENU_DATA } from "../../utils/data";
import { UserContext } from "../../context/UserContext";
import { useNavigate } from "react-router-dom";
import CharAvatar from "./Cards/CharAvatar";
import "./dashboard.css";

const SideMenu = ({ activeMenu }) => {
  const { user, clearUser } = useContext(UserContext);
  const navigate = useNavigate();

  const handleClick = (route) => {
    if (route === "logout") {
      handleLogout();
      return;
    }
    navigate(route);
  };

  const handleLogout = () => {
    localStorage.clear();
    clearUser();
    navigate("/login");
  };

  return (
    <div className="side-menu">
      <div className="side-menu-profile">
        {user?.profileImageUrl ? (
          <img
            src={user?.profileImageUrl}
            alt="Profile Image"
            className="side-menu-avatar"
          />
        ) : (
          <CharAvatar
            fullName={user?.fullName}
            width="w-20"
            height="h-20"
            style="text-xl"
          />
        )}

        <h5 className="side-menu-name">
          {user?.fullName || ""}
        </h5>
      </div>

      {/* Added container for proper spacing */}
      <div className="menu-items-group">
        {SIDE_MENU_DATA.map((item, index) => (
          <div key={`menu_${index}`} className="menu-button-container">
            <button
              className={`menu-button ${
                activeMenu === item.label ? "active" : "inactive"
              }`}
              onClick={() => handleClick(item.path)}
            >
              <item.icon className="menu-icon" />
              {item.label}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SideMenu;