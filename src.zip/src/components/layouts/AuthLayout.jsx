// src/components/layouts/AuthLayout.jsx
import React from "react";

const AuthLayout = ({ children }) => {
  return (
    <div className="auth-layout">
      {/* Heading */}
      <h2 className="auth-heading">
        Expense Tracker
      </h2>

      {/* Children (login form with "Welcome Back") */}
      <div className="auth-content">
        {children}
      </div>
    </div>
  );
};

export default AuthLayout;