// src/components/layouts/Navbar.jsx
import React from "react";
import { HiOutlineMenu, HiOutlineX } from "react-icons/hi";
import "./dashboard.css";

const Navbar = ({ activeMenu, onMenuToggle, showMobileMenu }) => {
  return (
    <div className="dashboard-navbar">
      <button
        className="navbar-menu-button"
        onClick={onMenuToggle}
        aria-label="Toggle Menu"
      >
        {showMobileMenu ? (
          <HiOutlineX className="menu-icon" />
        ) : (
          <HiOutlineMenu className="menu-icon" />
        )}
      </button>

      <h2 className="navbar-title">Expense Tracker</h2>
    </div>
  );
};

export default Navbar;