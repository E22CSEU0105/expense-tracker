import React, { useState } from "react";
import "../../../components/layouts/Modal.css";

const AddIncomeForm = ({ onAddIncome, onCancel }) => {
  const [source, setSource] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");
  const [selectedIcon, setSelectedIcon] = useState("💰");

  const incomeIcons = [
    "💰", "💼", "🏦", "📈", "💳", "🎯", "⭐", "🏆", 
    "💸", "🤑", "💎", "📊", "💰", "💵", "💶", "💷"
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddIncome({ source, amount, date, icon: selectedIcon });
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <form onSubmit={handleSubmit} className="add-income-form">
      <div className="form-section">
        <h3 className="form-section-title">Pick Icon</h3>
        <div className="icon-grid">
          {incomeIcons.map((icon, index) => (
            <button
              key={index}
              type="button"
              className={`icon-button ${selectedIcon === icon ? 'selected' : ''}`}
              onClick={() => setSelectedIcon(icon)}
            >
              {icon}
            </button>
          ))}
        </div>
      </div>

      <div className="form-section">
        <h3 className="form-section-title">Income Source</h3>
        <div className="form-group">
          <input
            type="text"
            placeholder="Freelance, Salary, etc"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            className="form-input"
            required
          />
        </div>
      </div>

      <div className="form-section">
        <h3 className="form-section-title">Amount</h3>
        <div className="form-group">
          <input
            type="number"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="form-input"
            min="0"
            step="0.01"
            required
          />
        </div>
      </div>

      <div className="form-section">
        <h3 className="form-section-title">Date</h3>
        <div className="form-group">
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="form-input"
            max={today}
            required
          />
        </div>
      </div>

      <div className="form-actions">
        <button type="button" className="btn-secondary" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn-primary">
          Add Income
        </button>
      </div>
    </form>
  );
};

export default AddIncomeForm;