// src/components/layouts/Income/AddIncomeModal.jsx
import React, { useState } from "react";
import { LuDollarSign, LuTag } from "react-icons/lu";
import { FaMoneyBillWave, FaTimes } from "react-icons/fa";
import "./Modals.css"; // Same directory

const AddIncomeModal = ({ isOpen, onClose, onAddIncome }) => {
  const [formData, setFormData] = useState({
    source: "",
    amount: "",
    description: "",
    icon: "💰" // default icon
  });

  const incomeIcons = [
    { icon: "💰", label: "Money" },
    { icon: "💼", label: "Salary" },
    { icon: "🎨", label: "Freelance" },
    { icon: "🏠", label: "Rent" },
    { icon: "📈", label: "Investment" },
    { icon: "🎁", label: "Gift" }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.source || !formData.amount) return;

    const incomeData = {
      ...formData,
      amount: parseFloat(formData.amount),
      date: new Date().toISOString(),
      id: Date.now()
    };

    onAddIncome(incomeData);
    setFormData({ source: "", amount: "", description: "", icon: "💰" });
    onClose();
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Add Income</h2>
          <button className="modal-close" onClick={onClose}>
            <FaTimes />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="income-form">
          {/* Icon Selection */}
          <div className="form-group">
            <label>Pick Icon</label>
            <div className="icon-grid">
              {incomeIcons.map((item) => (
                <button
                  key={item.label}
                  type="button"
                  className={`icon-option ${formData.icon === item.icon ? "selected" : ""}`}
                  onClick={() => setFormData({ ...formData, icon: item.icon })}
                >
                  <span className="icon">{item.icon}</span>
                  <span className="icon-label">{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Income Source */}
          <div className="form-group">
            <label htmlFor="source">Income Source</label>
            <div className="input-with-icon">
              <LuTag className="input-icon" />
              <input
                type="text"
                id="source"
                name="source"
                placeholder="Freelance, Salary, etc"
                value={formData.source}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          {/* Amount */}
          <div className="form-group">
            <label htmlFor="amount">Amount</label>
            <div className="input-with-icon">
              <LuDollarSign className="input-icon" />
              <input
                type="number"
                id="amount"
                name="amount"
                placeholder="0.00"
                step="0.01"
                value={formData.amount}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          {/* Description */}
          <div className="form-group">
            <label htmlFor="description">Description (Optional)</label>
            <div className="input-with-icon">
              <FaMoneyBillWave className="input-icon" />
              <input
                type="text"
                id="description"
                name="description"
                placeholder="Additional notes"
                value={formData.description}
                onChange={handleChange}
              />
            </div>
          </div>

          <button type="submit" className="submit-button">
            Add Income
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddIncomeModal;