import React from "react";
import "../../../components/layouts/dashboard.css";
import "./IncomeOverview.css"; // Create this CSS file

const IncomeOverview = ({ transactions, onAddIncome }) => {
  const totalIncome = transactions.reduce((sum, transaction) => sum + transaction.amount, 0);
  const formattedTotal = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(totalIncome);

  // Sample data for the chart
  const chartData = [
    { month: 'Jan', income: 4000 },
    { month: 'Feb', income: 5200 },
    { month: 'Mar', income: 4800 },
    { month: 'Apr', income: 5800 },
    { month: 'May', income: 6000 },
    { month: 'Jun', income: 7200 },
    { month: 'Jul', income: 6800 },
    { month: 'Aug', income: 7500 },
    { month: 'Sep', income: 7000 },
  ];

  // Find the maximum value for scaling
  const maxIncome = Math.max(...chartData.map(item => item.income));

  return (
    <div className="income-overview-container">
      <div className="income-overview-header">
        <h2>Income Overview</h2>
        <p>Track your earnings over time and analyze your income trends.</p>
      </div>
      
      <div className="income-stats">
        <div className="income-total">
          <span className="income-total-label">Total Income</span>
          <span className="income-total-amount">{formattedTotal}</span>
        </div>
        
        <div className="income-chart-container">
          <div className="custom-bar-chart">
            {chartData.map((item, index) => {
              const height = (item.income / maxIncome) * 100;
              return (
                <div key={index} className="chart-bar-container">
                  <div 
                    className="chart-bar" 
                    style={{ height: `${height}%` }}
                    title={`${item.month}: $${item.income}`}
                  >
                    <span className="chart-bar-value">${item.income}</span>
                  </div>
                  <span className="chart-bar-label">{item.month}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      
      <button className="add-income-card-btn" onClick={onAddIncome}>
        <i className="fas fa-plus"></i>
        Add Income
      </button>
    </div>
  );
};

export default IncomeOverview;