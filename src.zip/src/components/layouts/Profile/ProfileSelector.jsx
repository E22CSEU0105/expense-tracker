import React from 'react';
import { useUser } from '../../context/UserContext';

const ProfileSelector = () => {
    const { currentProfile, profiles, switchProfile, addProfile } = useUser();
    const [showAddForm, setShowAddForm] = useState(false);
    const [newProfileName, setNewProfileName] = useState('');

    const handleAddProfile = async (e) => {
        e.preventDefault();
        if (newProfileName.trim()) {
            await addProfile({ name: newProfileName.trim() });
            setNewProfileName('');
            setShowAddForm(false);
        }
    };

    return (
        <div className="profile-selector">
            <div className="current-profile">
                <span>Current Profile: </span>
                <strong>{currentProfile?.name || 'No Profile'}</strong>
            </div>
            
            <div className="profiles-dropdown">
                <select 
                    value={currentProfile?.id || ''} 
                    onChange={(e) => switchProfile(e.target.value)}
                    className="profile-dropdown"
                >
                    {profiles.map(profile => (
                        <option key={profile.id} value={profile.id}>
                            {profile.name}
                        </option>
                    ))}
                </select>
                
                <button 
                    onClick={() => setShowAddForm(true)}
                    className="add-profile-btn"
                >
                    + Add Profile
                </button>
            </div>

            {showAddForm && (
                <div className="add-profile-modal">
                    <form onSubmit={handleAddProfile}>
                        <input
                            type="text"
                            value={newProfileName}
                            onChange={(e) => setNewProfileName(e.target.value)}
                            placeholder="Enter profile name"
                            required
                        />
                        <button type="submit">Create</button>
                        <button type="button" onClick={() => setShowAddForm(false)}>
                            Cancel
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
};

export default ProfileSelector;