import React, { useState, useEffect } from "react";
import { useUserAuth } from "../../../hooks/useUserAuth.jsx";
import DashboardLayout from "../../../components/layouts/DashboardLayout";
import toast from "react-hot-toast";
import Modal from "../../../components/layouts/Modal";
import ExpenseOverview from "../../../components/layouts/Expense/ExpenseOverview";
import ExpenseList from "../../../components/layouts/Expense/ExpenseList";
import AddExpenseForm from "../../../components/layouts/Expense/AddExpenseForm";
import DeleteAlert from "../../../components/layouts/DeleteAlert";

// Temporary Plus icon component
const LuPlus = ({ size = 20 }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2"
  >
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

const Expense = () => {
  useUserAuth();

  const [expenseData, setExpenseData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [openDeleteAlert, setOpenDeleteAlert] = useState({
    show: false,
    data: null,
  });
  const [openAddExpenseModal, setOpenAddExpenseModal] = useState(false);

  // Get the current user ID
  const getCurrentUserId = () => {
    return localStorage.getItem('userId') || 'default-user';
  };

  // Generate a unique ID for expense entries
  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  // Load expense data from localStorage
  const fetchExpenseDetails = () => {
    setLoading(true);
    try {
      const userId = getCurrentUserId();
      const savedExpenses = localStorage.getItem(`userExpenses_${userId}`);
      if (savedExpenses) {
        setExpenseData(JSON.parse(savedExpenses));
      } else {
        setExpenseData([]);
      }
    } catch (error) {
      console.error("Failed to fetch expense details:", error);
      toast.error("Failed to fetch expense details.");
    } finally {
      setLoading(false);
    }
  };

  // Save expense data to localStorage
  const saveExpenseData = (data) => {
    const userId = getCurrentUserId();
    localStorage.setItem(`userExpenses_${userId}`, JSON.stringify(data));
  };

  const handleAddExpense = (expense) => {
    const { category, amount, date, icon, description } = expense;

    if (!category.trim()) {
      toast.error("Category is required.");
      return;
    }

    if (!amount || isNaN(amount) || Number(amount) <= 0) {
      toast.error("Amount should be a valid number greater than 0.");
      return;
    }

    if (!date) {
      toast.error("Date is required.");
      return;
    }

    try {
      const newExpense = {
        id: generateId(),
        category,
        amount: Number(amount),
        date,
        icon: icon || "💰",
        description: description || "",
        userId: getCurrentUserId()
      };

      const updatedExpenses = [...expenseData, newExpense];
      setExpenseData(updatedExpenses);
      saveExpenseData(updatedExpenses);
      
      setOpenAddExpenseModal(false);
      toast.success("Expense added successfully");
    } catch (error) {
      console.error("Error adding expense:", error);
      toast.error("Failed to add expense. Please try again.");
    }
  };

  const deleteExpense = (id) => {
    try {
      const updatedExpenses = expenseData.filter(expense => expense.id !== id);
      setExpenseData(updatedExpenses);
      saveExpenseData(updatedExpenses);
      
      setOpenDeleteAlert({ show: false, data: null });
      toast.success("Expense details deleted successfully");
    } catch (error) {
      console.error("Error deleting expense:", error);
      toast.error("Failed to delete expense. Please try again.");
    }
  };

  const handleDownloadExpenseDetails = () => {
    try {
      // Create CSV content
      const headers = "Category,Amount,Date,Description\n";
      const csvContent = expenseData.reduce((csv, expense) => {
        return csv + `"${expense.category}",${expense.amount},"${expense.date}","${expense.description}"\n`;
      }, headers);

      // Create blob and download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", "expense_details.csv");
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success("Expense details downloaded successfully");
    } catch (error) {
      console.error("Error downloading expense details:", error);
      toast.error("Failed to download expense details. Please try again.");
    }
  };

  useEffect(() => {
    fetchExpenseDetails();
  }, []);

  return (
    <DashboardLayout activeMenu="Expense">
      <div className="dashboard-main-container">
        {/* Add Expense Button Header */}
        <div className="dashboard-header">
          <h1>Expense Overview</h1>
          <button 
            className="add-income-btn"
            onClick={() => setOpenAddExpenseModal(true)}
          >
            <LuPlus />
            Add Expense
          </button>
        </div>

        <div className="dashboard-grid-layout">
          <ExpenseOverview
            transactions={expenseData}
            onAddExpense={() => setOpenAddExpenseModal(true)}
          />

          <ExpenseList
            transactions={expenseData}
            onDelete={(id) => setOpenDeleteAlert({ show: true, data: id })}
            onDownload={handleDownloadExpenseDetails}
          />
        </div>

        <Modal
          isOpen={openAddExpenseModal}
          onClose={() => setOpenAddExpenseModal(false)}
          title="Add Expense"
        >
          <AddExpenseForm 
            onExpenseAdded={handleAddExpense}
            onClose={() => setOpenAddExpenseModal(false)}
          />
        </Modal>

        <Modal
          isOpen={openDeleteAlert.show}
          onClose={() => setOpenDeleteAlert({ show: false, data: null })}
          title="Delete Expense"
        >
          <DeleteAlert
            content="Are you sure you want to delete this expense detail?"
            onDelete={() => deleteExpense(openDeleteAlert.data)}
            onCancel={() => setOpenDeleteAlert({ show: false, data: null })}
          />
        </Modal>
      </div>
    </DashboardLayout>
  );
};

export default Expense;