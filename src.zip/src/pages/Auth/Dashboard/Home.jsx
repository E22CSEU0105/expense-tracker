import React, { useState, useEffect } from "react";
import DashboardLayout from "../../../components/layouts/DashboardLayout";
import { useUserAuth } from "../../../hooks/useUserAuth.jsx";
import { useNavigate } from "react-router-dom";
import AddIncomeModal from "../../../components/layouts/Income/AddIncomeModal";
import RecentTransactions from "../../../components/layouts/Dashboard/RecentTransactions";
import FinanceOverview from "../../../components/layouts/Dashboard/FinanceOverview";
import Last30DaysExpenses from "../../../components/layouts/Dashboard/Last30DaysExpenses";
import RecentIncomeWithChart from "../../../components/layouts/Dashboard/RecentIncomeWithChart";
import { LuHandCoins, LuWalletMinimal, LuPlus } from "react-icons/lu";
import { IoMdCard } from "react-icons/io";
import { addThousandsSeparator } from "../../../utils/helper";
import "../../../components/layouts/dashboard.css";

const Home = () => {
  const { user } = useUserAuth();
  const navigate = useNavigate();
  const [isAddIncomeModalOpen, setIsAddIncomeModalOpen] = useState(false);
  const [userIncomes, setUserIncomes] = useState([]);
  const [userExpenses, setUserExpenses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Get the current user ID
  const getCurrentUserId = () => {
    return localStorage.getItem('userId') || 'default-user';
  };

  // Load all data from localStorage
  const loadDataFromStorage = () => {
    try {
      const userId = getCurrentUserId();
      const savedIncomes = JSON.parse(localStorage.getItem(`userIncomes_${userId}`) || '[]');
      const savedExpenses = JSON.parse(localStorage.getItem(`userExpenses_${userId}`) || '[]');
      
      setUserIncomes(savedIncomes);
      setUserExpenses(savedExpenses);
    } catch (error) {
      console.error("Error loading data from localStorage:", error);
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    loadDataFromStorage();
  }, []);

  // Listen for storage changes (from other tabs/windows)
  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key?.startsWith('userIncomes_') || e.key?.startsWith('userExpenses_')) {
        loadDataFromStorage();
      }
    };

    // Listen for custom events (from same tab)
    const handleCustomStorageChange = () => {
      loadDataFromStorage();
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('localStorageUpdate', handleCustomStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('localStorageUpdate', handleCustomStorageChange);
    };
  }, []);

  // Save data to localStorage with user-specific keys and trigger updates
  const saveIncomes = (incomes) => {
    const userId = getCurrentUserId();
    localStorage.setItem(`userIncomes_${userId}`, JSON.stringify(incomes));
    // Trigger custom event for real-time updates
    window.dispatchEvent(new Event('localStorageUpdate'));
  };

  const saveExpenses = (expenses) => {
    const userId = getCurrentUserId();
    localStorage.setItem(`userExpenses_${userId}`, JSON.stringify(expenses));
    // Trigger custom event for real-time updates
    window.dispatchEvent(new Event('localStorageUpdate'));
  };

  // Calculate everything from localStorage data
  const totalUserIncome = userIncomes.reduce((sum, income) => sum + (income.amount || 0), 0);
  const totalUserExpense = userExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);
  const calculatedBalance = totalUserIncome - totalUserExpense;

  // Get last 30 days expenses for the chart
  const getLast30DaysExpenses = () => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    return userExpenses.filter(expense => {
      const expenseDate = new Date(expense.date);
      return expenseDate >= thirtyDaysAgo;
    });
  };

  const last30DaysExpenses = getLast30DaysExpenses();

  const handleAddIncome = (incomeData) => {
    const newIncome = {
      ...incomeData,
      id: Date.now() + Math.random(),
      date: new Date().toISOString(),
      userId: getCurrentUserId(),
      type: 'income',
      description: incomeData.description || 'Added income'
    };
    
    const updatedIncomes = [...userIncomes, newIncome];
    setUserIncomes(updatedIncomes);
    saveIncomes(updatedIncomes);
    setIsAddIncomeModalOpen(false);
  };

  const handleDeleteIncome = (incomeId) => {
    const updatedIncomes = userIncomes.filter(income => income.id !== incomeId);
    setUserIncomes(updatedIncomes);
    saveIncomes(updatedIncomes);
  };

  const handleDeleteTransaction = (transactionId, type) => {
    if (type === 'income') {
      const updatedIncomes = userIncomes.filter(income => income.id !== transactionId);
      setUserIncomes(updatedIncomes);
      saveIncomes(updatedIncomes);
    } else {
      const updatedExpenses = userExpenses.filter(expense => expense.id !== transactionId);
      setUserExpenses(updatedExpenses);
      saveExpenses(updatedExpenses);
    }
  };

  // Combine transactions for recent transactions list
  const allTransactions = [
    ...userIncomes.map(income => ({
      id: income.id,
      amount: income.amount,
      category: income.source || 'Income',
      date: income.date,
      type: 'income',
      description: income.description || 'Income'
    })),
    ...userExpenses.map(expense => ({
      id: expense.id,
      amount: expense.amount,
      category: expense.category || 'Expense',
      date: expense.date,
      type: 'expense',
      description: expense.description || 'Expense'
    }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);

  if (loading) {
    return (
      <DashboardLayout activeMenu="Dashboard">
        <div className="dashboard-main-container">
          <div className="loading-spinner">Loading...</div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout activeMenu="Dashboard">
      <div className="dashboard-main-container">
        {/* Header with Add Income Button */}
        <div className="dashboard-header">
          <h1>Income Overview</h1>
          <button 
            className="add-income-btn"
            onClick={() => setIsAddIncomeModalOpen(true)}
            disabled={loading}
          >
            <LuPlus /> Add Income
          </button>
        </div>

        {/* Dashboard Cards */}
        <div className="dashboard-cards-grid">
          <div className="info-card">
            <div className="info-card-icon">
              <IoMdCard />
            </div>
            <div className="info-card-content">
              <span className="info-card-label">Total Balance</span>
              <span className="info-card-value">
                ${addThousandsSeparator(calculatedBalance)}
              </span>
            </div>
          </div>

          <div className="info-card">
            <div className="info-card-icon">
              <LuWalletMinimal />
            </div>
            <div className="info-card-content">
              <span className="info-card-label">Total Income</span>
              <span className="info-card-value income-value">
                ${addThousandsSeparator(totalUserIncome)}
              </span>
            </div>
          </div>

          <div className="info-card">
            <div className="info-card-icon">
              <LuHandCoins />
            </div>
            <div className="info-card-content">
              <span className="info-card-label">Total Expense</span>
              <span className="info-card-value">
                ${addThousandsSeparator(totalUserExpense)}
              </span>
            </div>
          </div>
        </div>

        {/* Dashboard Content Grid */}
        <div className="dashboard-grid-layout">
          <RecentTransactions
            transactions={allTransactions}
            onSeeMore={() => navigate("/expense")}
            onDeleteTransaction={handleDeleteTransaction}
          />
          
          <FinanceOverview
            totalBalance={calculatedBalance}
            totalIncome={totalUserIncome}
            totalExpense={totalUserExpense}
          />
          
          <Last30DaysExpenses
            data={last30DaysExpenses}
          />
          
          <RecentIncomeWithChart
            data={userIncomes.slice(-6)}
            totalIncome={totalUserIncome}
          />
        </div>

        {/* Add Income Modal */}
        <AddIncomeModal
          isOpen={isAddIncomeModalOpen}
          onClose={() => setIsAddIncomeModalOpen(false)}
          onAddIncome={handleAddIncome}
        />
      </div>
    </DashboardLayout>
  );
};

export default Home;