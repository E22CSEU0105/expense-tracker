import React, { useState, useEffect } from "react";
import DashboardLayout from "../../../components/layouts/DashboardLayout";
import IncomeOverview from "../../../components/layouts/Income/IncomeOverview";
import AddIncomeForm from "../../../components/layouts/Income/AddIncomeForm";
import IncomeList from "../../../components/layouts/Income/IncomeList";
import DeleteAlert from "../../../components/layouts/DeleteAlert";
import Modal from "../../../components/layouts/Modal";
import toast from "react-hot-toast";
import { useUserAuth } from "../../../hooks/useUserAuth.jsx";
import { LuPlus } from "react-icons/lu";
import "../../../components/layouts/dashboard.css";

const Income = () => {
  useUserAuth();

  const [incomeData, setIncomeData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [openDeleteAlert, setOpenDeleteAlert] = useState({ show: false, data: null });
  const [openAddIncomeModal, setOpenAddIncomeModal] = useState(false);

  // Get the current user ID
  const getCurrentUserId = () => {
    return localStorage.getItem('userId') || 'default-user';
  };

  // Generate a unique ID for income entries
  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  // Load income data from localStorage
  const fetchIncomeDetails = () => {
    setLoading(true);
    try {
      const userId = getCurrentUserId();
      const savedIncomes = localStorage.getItem(`userIncomes_${userId}`);
      if (savedIncomes) {
        setIncomeData(JSON.parse(savedIncomes));
      } else {
        setIncomeData([]);
      }
    } catch (error) {
      console.error("Failed to fetch income details:", error);
      toast.error("Failed to fetch income details.");
    } finally {
      setLoading(false);
    }
  };

  // Save income data to localStorage
  const saveIncomeData = (data) => {
    const userId = getCurrentUserId();
    localStorage.setItem(`userIncomes_${userId}`, JSON.stringify(data));
  };

  const handleAddIncome = (income) => {
    const { source, amount, date, icon } = income;

    if (!source.trim()) return toast.error("Source is required.");
    if (!amount || isNaN(amount) || Number(amount) <= 0) return toast.error("Amount should be a valid number greater than 0.");
    if (!date) return toast.error("Date is required.");

    try {
      const newIncome = {
        id: generateId(),
        source,
        amount: Number(amount),
        date,
        icon: icon || "💰",
        userId: getCurrentUserId()
      };

      const updatedIncomes = [...incomeData, newIncome];
      setIncomeData(updatedIncomes);
      saveIncomeData(updatedIncomes);
      
      setOpenAddIncomeModal(false);
      toast.success("Income added successfully");
    } catch (error) {
      console.error("Error adding income:", error);
      toast.error("Failed to add income. Please try again.");
    }
  };

  const deleteIncome = (id) => {
    try {
      const updatedIncomes = incomeData.filter(income => income.id !== id);
      setIncomeData(updatedIncomes);
      saveIncomeData(updatedIncomes);
      
      setOpenDeleteAlert({ show: false, data: null });
      toast.success("Income details deleted successfully");
    } catch (error) {
      console.error("Error deleting income:", error);
      toast.error("Failed to delete income. Please try again.");
    }
  };

  const handleDownloadIncomeDetails = () => {
    try {
      // Create CSV content
      const headers = "Source,Amount,Date\n";
      const csvContent = incomeData.reduce((csv, income) => {
        return csv + `"${income.source}",${income.amount},"${income.date}"\n`;
      }, headers);

      // Create blob and download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", "income_details.csv");
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success("Income details downloaded successfully");
    } catch (error) {
      console.error("Error downloading income details:", error);
      toast.error("Failed to download income details. Please try again.");
    }
  };

  useEffect(() => {
    fetchIncomeDetails();
  }, []);

  return (
    <DashboardLayout activeMenu="Income">
      <div className="dashboard-main-container">
        {/* Add Income Button Header */}
        <div className="dashboard-header">
          <h1>Income Overview</h1>
          <button 
            className="add-income-btn"
            onClick={() => setOpenAddIncomeModal(true)}
          >
            <LuPlus />
            Add Income
          </button>
        </div>

        <div className="dashboard-grid-layout">
          <IncomeOverview
            transactions={incomeData}
            onAddIncome={() => setOpenAddIncomeModal(true)}
          />

          <IncomeList
            transactions={incomeData}
            onDelete={(id) => setOpenDeleteAlert({ show: true, data: id })}
            onDownload={handleDownloadIncomeDetails}
          />
        </div>

        <Modal isOpen={openAddIncomeModal} onClose={() => setOpenAddIncomeModal(false)} title="Add Income">
          <AddIncomeForm onAddIncome={handleAddIncome} onCancel={() => setOpenAddIncomeModal(false)} />
        </Modal>

        <Modal isOpen={openDeleteAlert.show} onClose={() => setOpenDeleteAlert({ show: false, data: null })} title="Delete Income">
          <DeleteAlert
            content="Are you sure you want to delete this income detail?"
            onDelete={() => deleteIncome(openDeleteAlert.data)}
            onCancel={() => setOpenDeleteAlert({ show: false, data: null })}
          />
        </Modal>
      </div>
    </DashboardLayout>
  );
};

export default Income;