import React, { useState, useContext, useRef } from 'react';
import AuthLayout from '../../components/layouts/AuthLayout';
import { useNavigate, Link } from 'react-router-dom';
import { validateEmail } from "../../utils/helper";
import { UserContext } from "../../context/UserContext";
import './signup.css';

const SignUp = () => {
  const [profilePic, setProfilePic] = useState(null);
  const [profilePreview, setProfilePreview] = useState(null);
  const [profileImageUrl, setProfileImageUrl] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const { updateUser } = useContext(UserContext);
  const navigate = useNavigate();

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePic(file);
      
      const reader = new FileReader();
      reader.onloadend = () => setProfilePreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setProfilePic(null);
    setProfilePreview(null);
    setProfileImageUrl("");
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Save user data to localStorage instead of backend
  const saveUserToFile = (userData) => {
    try {
      const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
      
      const userExists = existingUsers.some(user => user.email === userData.email);
      if (userExists) {
        throw new Error('User with this email already exists');
      }
      
      existingUsers.push(userData);
      localStorage.setItem('users', JSON.stringify(existingUsers));
      return true;
    } catch (error) {
      console.error('Error saving user:', error);
      throw error;
    }
  };

  const handleSignUp = async (e) => {
    e.preventDefault();

    if (!fullName.trim()) {
      setError("Please enter your name.");
      return;
    }
    if (!email.trim() || !validateEmail(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }
    if (!password || password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const userData = {
        id: Date.now().toString(),
        fullName,
        email: email.trim(),
        password, // ⚠️ In real apps, never store plain password!
        profileImageUrl: profilePreview || "",
        createdAt: new Date().toISOString()
      };

      saveUserToFile(userData);

      const token = btoa(JSON.stringify({ 
        id: userData.id, 
        email: userData.email 
      }));
      
      localStorage.setItem("token", token);
      updateUser(userData);
      navigate("/dashboard");
      
    } catch (error) {
      setError(error.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      <div className="signup-container">
        <h3 className="signup-title">Create an Account</h3>
        <p className="signup-subtitle">Join us today by entering your details below.</p>

        <form onSubmit={handleSignUp} className="signup-form">
          <div className="profile-photo-selector">
            <label htmlFor="profile-photo" className="input-label">Choose Profile Photo</label>
            
            <div className="file-input-container">
              <input
                id="profile-photo"
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="profile-photo-input"
                disabled={uploading || loading}
              />
              <label htmlFor="profile-photo" className="file-input-label">
                <i className="fas fa-upload"></i> 
                {uploading ? 'Uploading...' : 'Choose File'}
              </label>
            </div>

            {profilePreview && (
              <div className="image-preview-container">
                <div className="image-preview">
                  <img src={profilePreview} alt="Profile preview" />
                  <button 
                    type="button" 
                    className="remove-image-btn"
                    onClick={handleRemoveImage}
                    disabled={uploading || loading}
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
                <p className="file-selected">{profilePic.name}</p>
              </div>
            )}
          </div>

          <div className="input-group">
            <label htmlFor="fullName" className="input-label">Full Name</label>
            <input
              id="fullName"
              type="text"
              value={fullName}
              onChange={({ target }) => setFullName(target.value)}
              placeholder="John"
              className="input-field"
              required
              disabled={loading || uploading}
            />
          </div>

          <div className="input-group">
            <label htmlFor="email" className="input-label">Email Address</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={({ target }) => setEmail(target.value)}
              placeholder="John@example.com"
              className="input-field"
              required
              disabled={loading || uploading}
            />
          </div>

          <div className="input-group">
            <label htmlFor="password" className="input-label">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={({ target }) => setPassword(target.value)}
              placeholder="Min 8 Characters"
              className="input-field"
              required
              minLength="8"
              disabled={loading || uploading}
            />
          </div>

          {error && <p className="error-message">{error}</p>}

          <button 
            type="submit" 
            className="btn-primary"
            disabled={loading || uploading}
          >
            {loading ? 'Creating Account...' : 
             uploading ? 'Uploading Image...' : 'SIGN UP'}
          </button>

          <p className="login-text">
            Already have an account?{" "}
            <Link className="login-link" to="/login">Login</Link>
          </p>
        </form>
      </div>
    </AuthLayout>
  );
};

export default SignUp;
