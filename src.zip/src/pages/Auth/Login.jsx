import React, { useState, useContext } from 'react';
import AuthLayout from '../../components/layouts/AuthLayout';
import { useNavigate, Link } from 'react-router-dom';
import { validateEmail } from '../../utils/helper';
import { UserContext } from "../../context/UserContext";
import './login.css';

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const { updateUser } = useContext(UserContext);
  const navigate = useNavigate();

  // Function to verify login credentials against file data
  const verifyCredentials = (email, password) => {
    try {
      // Get users from file
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      
      // Find user with matching email and password
      const user = users.find(u => u.email === email.trim() && u.password === password);
      
      if (user) {
        // Create a simple token
        const token = btoa(JSON.stringify({ 
          id: user.id, 
          email: user.email 
        }));
        
        return { success: true, user, token };
      } else {
        return { success: false, message: 'Invalid email or password' };
      }
    } catch (error) {
      console.error('Error verifying credentials:', error);
      return { success: false, message: 'Authentication error' };
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    if (!email || !validateEmail(email.trim())) {
      setError('Please enter a valid email address.');
      return;
    }

    if (!password) {
      setError('Please enter your password.');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      // Verify credentials against file
      const result = verifyCredentials(email, password);
      
      if (result.success) {
        const { token, user } = result;
        
        localStorage.setItem('token', token);
        updateUser(user);
        navigate('/dashboard');
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError(err.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      <div className="login-container">
        <h3 className="login-title">Welcome Back</h3>
        <p className="login-subtitle">
          Please enter your details to log in
        </p>

        <form onSubmit={handleLogin} className="login-form">
          <div className="input-group">
            <label htmlFor="email" className="input-label">Email Address</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={({ target }) => setEmail(target.value)}
              placeholder="John@example.com"
              className="input-field"
            />
          </div>

          <div className="input-group">
            <label htmlFor="password" className="input-label">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={({ target }) => setPassword(target.value)}
              placeholder="Min 8 Characters"
              className="input-field"
            />
          </div>

          {error && <p className="error-message">{error}</p>}

          <button
            type="submit"
            className="btn-primary"
            disabled={loading}
          >
            {loading ? 'Logging in…' : 'LOGIN'}
          </button>

          <p className="signup-text">
            Don't have an account?{' '}
            <Link className="signup-link" to="/signUp">
              Sign Up
            </Link>
          </p>
        </form>
        
        {/* Add the stats card directly in the login component */}
        <div className="stats-card">
          <div className="stats-icon">
            <i className="fas fa-chart-line"></i>
          </div>
          <div className="stats-content">
            <h6 className="stats-label">Track Your Income & Expenses</h6>
            <span className="stats-value">$430,000</span>
          </div>
        </div>
        
        <div className="stats-actions">
          <button>All Transactions</button>
          <button>Save Annual 2020 Date</button>
        </div>
        
        <a href="#" className="view-more">View More</a>
      </div>
    </AuthLayout>
  );
};

export default Login;